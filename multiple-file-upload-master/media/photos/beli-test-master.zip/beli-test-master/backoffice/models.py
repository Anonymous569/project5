from django.db import models
from django.core.files import File
from django.contrib.auth.models import PermissionsMixin
from django.contrib.auth.base_user import AbstractBaseUser
from django.db import models
from django.contrib.gis.db import models
from django.contrib.gis.geos import Point
from backoffice.UserManager import UserManager
from django.contrib.auth.hashers import get_hasher, identify_hasher
import uuid
from django.utils.timezone import now

class ParameterFloat(models.Model):
    field = models.ForeignKey('Field', on_delete=models.CASCADE)
    start_dt = models.DateTimeField(default=now)
    end_dt = models.DateTimeField(null=True)
    value = models.FloatField()

    class Meta:
        verbose_name = ('Parameter')
        verbose_name_plural = ('Parameters')

class Share(models.Model):
    user = models.ForeignKey('User', on_delete=models.CASCADE)
    business = models.ForeignKey('Business', on_delete=models.CASCADE)
    sent_dt = models.DateTimeField(default=now)

    class Meta:
        verbose_name = ('Share')
        verbose_name_plural = ('Shares')

# user table
class User(AbstractBaseUser, PermissionsMixin):
    id = models.UUIDField(primary_key=True, default=uuid.uuid4, editable=False)
    first_name = models.CharField(max_length=100, null=True, blank=True)
    last_name = models.CharField(max_length=100, null=True, blank=True)
    email = models.EmailField(unique=True, db_index=True)
    created_dt = models.DateTimeField(default=now)

    is_staff = models.BooleanField(('staff'), default=False)
    
    objects = UserManager()
    USERNAME_FIELD = 'email'
    REQUIRED_FIELDS = []

    class Meta:
        verbose_name = ('User')
        verbose_name_plural = ('Users')

# field table
class Field(models.Model):
    name = models.CharField(max_length=100, db_index=True)
    description = models.TextField()
    table = models.CharField(max_length=100, blank=False, null=False)
    created_dt = models.DateTimeField(default=now)

    class Meta:
        verbose_name = ('Field')
        verbose_name_plural = ('Fields')
        
# entity tables
class Chain(models.Model):
    name = models.CharField(max_length=100, db_index=True)
    created_dt = models.DateTimeField(default=now)

    class Meta:
        verbose_name = ('Chain')
        verbose_name_plural = ('Chains')

class Business(models.Model):
    name = models.CharField(max_length=100)
    chain = models.ForeignKey('Chain', on_delete=models.CASCADE, blank=True, null=True)
    place_id = models.CharField(max_length=100, null=True, blank=True, unique=True)
    created_dt = models.DateTimeField(default=now)

    class Meta:
        verbose_name = ('Business')
        verbose_name_plural = ('Businesses')

class BusinessView(models.Model):
    name = models.CharField(max_length=100)
    chain = models.ForeignKey('Chain', on_delete=models.CASCADE, blank=True, null=True)
    place_id = models.CharField(max_length=100, null=True, blank=True, unique=True)
    created_dt = models.DateTimeField(default=now)
    lat = models.FloatField()
    lng = models.FloatField()
    pricecode = models.IntegerField()
    city = models.CharField(max_length=100)

    class Meta:
        managed = False
        db_table = "backoffice_BusinessView"  

# data tables     
class DataUserBoolean(models.Model):
    field = models.ForeignKey('Field', on_delete=models.CASCADE)
    start_dt = models.DateTimeField(default=now)
    end_dt = models.DateTimeField(null=True)

    user = models.ForeignKey('User', on_delete=models.CASCADE)
    value = models.BooleanField()

    class Meta:
        verbose_name = ('DataUserBoolean')
        verbose_name_plural = ('DataUserBoolean')

class DataBusinessBoolean(models.Model):
    field = models.ForeignKey('Field', on_delete=models.CASCADE)
    start_dt = models.DateTimeField(default=now)
    end_dt = models.DateTimeField(null=True, blank=True) 

    business = models.ForeignKey('Business', on_delete=models.CASCADE)
    value = models.BooleanField()

    class Meta:
        verbose_name = ('DataBusinessBoolean')
        verbose_name_plural = ('DataBusinessBoolean')

class DataBusinessInteger(models.Model):
    field = models.ForeignKey('Field', on_delete=models.CASCADE)
    start_dt = models.DateTimeField(default=now)
    end_dt = models.DateTimeField(null=True, blank=True) 

    business = models.ForeignKey('Business', on_delete=models.CASCADE)
    value = models.IntegerField()

    class Meta:
        verbose_name = ('DataBusinessInteger')
        verbose_name_plural = ('DataBusinessInteger')

class DataBusinessFloat(models.Model):
    field = models.ForeignKey('Field', on_delete=models.CASCADE)
    start_dt = models.DateTimeField(default=now)
    end_dt = models.DateTimeField(null=True, blank=True) 

    business = models.ForeignKey('Business', on_delete=models.CASCADE)
    value = models.FloatField()

    class Meta:
        verbose_name = ('DataBusinessFloat')
        verbose_name_plural = ('DataBusinessFloat')

class DataBusinessVarchar(models.Model):
    field = models.ForeignKey('Field', on_delete=models.CASCADE)
    start_dt = models.DateTimeField(default=now)
    end_dt = models.DateTimeField(null=True, blank=True) 

    business = models.ForeignKey('Business', on_delete=models.CASCADE)
    value = models.CharField(max_length=100)

    class Meta:
        verbose_name = ('DataBusinessVarchar')
        verbose_name_plural = ('DataBusinessVarchar')

class DataUserBusinessBoolean(models.Model):
    field = models.ForeignKey('Field', on_delete=models.CASCADE)
    start_dt = models.DateTimeField(default=now)
    end_dt = models.DateTimeField(null=True) 

    user = models.ForeignKey('User', on_delete=models.CASCADE)
    business = models.ForeignKey('Business', on_delete=models.CASCADE)
    value = models.BooleanField()

    class Meta:
        verbose_name = ('DataUserBusinessBoolean')
        verbose_name_plural = ('DataUserBusinessBoolean')

class DataUserBusinessInteger(models.Model):
    field = models.ForeignKey('Field', on_delete=models.CASCADE)
    start_dt = models.DateTimeField(default=now)
    end_dt = models.DateTimeField(null=True) 

    user = models.ForeignKey('User', on_delete=models.CASCADE)
    business = models.ForeignKey('Business', on_delete=models.CASCADE)
    value = models.IntegerField()

    class Meta:
        verbose_name = ('DataUserBusinessInteger')
        verbose_name_plural = ('DataUserBusinessInteger')

class DataUserBusinessText(models.Model):
    field = models.ForeignKey('Field', on_delete=models.CASCADE)
    start_dt = models.DateTimeField(default=now)
    end_dt = models.DateTimeField(null=True) 

    user = models.ForeignKey('User', on_delete=models.CASCADE)
    business = models.ForeignKey('Business', on_delete=models.CASCADE)
    value = models.TextField()

    class Meta:
        verbose_name = ('DataUserBusinessText')
        verbose_name_plural = ('DataUserBusinessText')

class Follow(models.Model):
    follower = models.ForeignKey('User', on_delete=models.CASCADE, related_name='follower')
    followed = models.ForeignKey('User', on_delete=models.CASCADE, related_name='followed')
    request_dt = models.DateTimeField(default=now)
    accept_dt = models.DateTimeField(default=now) # Change if/when we have an accept workflow
    unfollow_dt = models.DateTimeField(null=True)
    unaccept_dt = models.DateTimeField(null=True)

    class Meta:
        constraints = [
            models.UniqueConstraint(fields=['follower', 'followed', 'request_dt'], name='unique_follow')
        ]
        verbose_name = ('Follow')
        verbose_name_plural = ('Follows')

class Activity(models.Model):
    user = models.ForeignKey('User', on_delete=models.CASCADE)
    field = models.ForeignKey('Field', on_delete=models.CASCADE)
    timestamp = models.DateTimeField(default=now)

    class Meta:
        verbose_name = ('Activity')
        verbose_name_plural = ('Activities')

class City(models.Model):
    name = models.CharField(max_length=100, null=True, blank=True)
    place_id = models.CharField(max_length=100, null=True, blank=True, unique=True)
    parent = models.ForeignKey('City', on_delete=models.CASCADE)
    created_dt = models.DateTimeField(default=now)

    class Meta:
        verbose_name = ('City')
        verbose_name_plural = ('Cities')

    
    

        
    
    
    
