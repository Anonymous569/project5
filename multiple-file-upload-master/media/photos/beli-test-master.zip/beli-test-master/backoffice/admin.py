from django.contrib import admin

# Register your models here.
from .models import *

admin.site.register(User)
admin.site.register(Field)
admin.site.register(Business)
admin.site.register(Chain)
admin.site.register(DataUserBoolean)
admin.site.register(DataBusinessBoolean)
admin.site.register(DataUserBusinessBoolean)
admin.site.register(DataUserBusinessInteger)
