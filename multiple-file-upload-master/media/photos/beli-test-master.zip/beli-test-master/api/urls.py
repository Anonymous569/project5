from django.urls import path, re_path
from django.conf.urls import include
from rest_framework.routers import DefaultRouter
router = DefaultRouter()
from api import views

urlpatterns = [
    path('datauserbusinessinteger/', views.DataUserBusinessIntegerListView.as_view(), name='data_user_business_integer'),
    path('closedatauserbusinessinteger/', views.DataUserBusinessIntegerCloseView.as_view(), name='close_data_user_business_integer'),
    path('closedatauserbusinessboolean/', views.DataUserBusinessBooleanCloseView.as_view(), name='close_data_user_business_boolean'),
    path('closedatauserbusinesstext/', views.DataUserBusinessTextCloseView.as_view(), name='close_data_user_business_text'),
    path('datauserbusinessboolean/', views.DataUserBusinessBooleanListView.as_view(), name='data_user_business_boolean'),
    path('datauserbusinesstext/', views.DataUserBusinessTextListView.as_view(), name='data_user_business_text'),
    path('databusinessboolean/', views.DataBusinessBooleanListView.as_view(), name='data_business_boolean'),
    path('databusinessinteger/', views.DataBusinessIntegerListView.as_view(), name='data_business_integer'),
    path('databusinessfloat/', views.DataBusinessFloatListView.as_view(), name='data_business_float'),
    path('databusinessvarchar/', views.DataBusinessVarcharListView.as_view(), name='data_business_varchar'),
    path('businessfromplaceid/<str:place_id>/', views.BusinessListView.as_view(), name='business_from_place_id'),
    path('datauserboolean/', views.DataUserBooleanListView.as_view(), name='data_user_boolean'),
    path('business/', views.BusinessListView.as_view(), name='business'),
    path('field/', views.FieldListView.as_view(), name='field'),
    path('user/', views.UserListView.as_view(), name='user'),
    path('follow/', views.FollowListView.as_view(), name='follow'),
    path('follow/<int:pk>/', views.FollowListView.as_view(), name="follow-update"),
    path('corr/<str:user_1>/<str:user_2>/', views.CorrView.as_view(), name='corr'),
    path('recs/<str:user>/', views.RecommendationView.as_view(), name='recs'),
    path('activity/', views.ActivityListView.as_view(), name='activity'),
    path('share/', views.ShareListView.as_view(), name='share'),
    path('count/<int:field>/', views.UserBusinessDataCountView.as_view(), name='count'),
    path('', include(router.urls))
]