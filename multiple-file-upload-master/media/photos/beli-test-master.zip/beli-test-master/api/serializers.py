from backoffice.models import Field, User, Business, DataUserBusinessInteger, DataUserBusinessBoolean, DataBusinessBoolean, DataUserBoolean, Share, DataBusinessInteger, DataBusinessFloat, DataBusinessVarchar, BusinessView, DataUserBusinessText, Follow, Activity
from rest_framework import serializers

class FieldSerializer(serializers.ModelSerializer):
    class Meta:
        model = Field
        fields = '__all__'

class BusinessSerializer(serializers.ModelSerializer):
    class Meta:
        model = Business
        fields = '__all__'

class BusinessSerializerRead(serializers.ModelSerializer):
    class Meta:
        model = Business
        fields = '__all__'   

class UserSerializer(serializers.ModelSerializer):
    class Meta:
        model = User
        fields = '__all__'

class DataUserBusinessIntegerSerializer(serializers.ModelSerializer):
    class Meta:
        model = DataUserBusinessInteger
        fields = '__all__'

class DataUserBusinessIntegerSerializerRead(DataUserBusinessIntegerSerializer):
    business = BusinessSerializer(read_only=True)

class DataUserBusinessBooleanSerializer(serializers.ModelSerializer):
    class Meta:
        model = DataUserBusinessBoolean
        fields = '__all__'

class DataUserBusinessBooleanSerializerRead(DataUserBusinessBooleanSerializer):
    business = BusinessSerializer(read_only=True)
    field = FieldSerializer(read_only=True)

class DataBusinessBooleanSerializer(serializers.ModelSerializer):
    class Meta:
        model = DataBusinessBoolean
        fields = '__all__'

class DataBusinessIntegerSerializer(serializers.ModelSerializer):
    class Meta:
        model = DataBusinessInteger
        fields = '__all__'

class DataBusinessFloatSerializer(serializers.ModelSerializer):
    class Meta:
        model = DataBusinessFloat
        fields = '__all__'

class DataBusinessVarcharSerializer(serializers.ModelSerializer):
    class Meta:
        model = DataBusinessVarchar
        fields = '__all__'

class DataBusinessBooleanSerializerRead(DataBusinessBooleanSerializer):
    business = BusinessSerializer(read_only=True)

class DataBusinessIntegerSerializerRead(DataBusinessIntegerSerializer):
    business = BusinessSerializer(read_only=True)

class DataBusinessFloatSerializerRead(DataBusinessFloatSerializer):
    business = BusinessSerializer(read_only=True)

class DataBusinessVarcharSerializerRead(DataBusinessVarcharSerializer):
    business = BusinessSerializer(read_only=True)

class DataUserBooleanSerializer(serializers.ModelSerializer):
    class Meta:
        model = DataUserBoolean
        fields = '__all__'

class DataUserBusinessTextSerializer(serializers.ModelSerializer):
    class Meta:
        model = DataUserBusinessText
        fields = '__all__'

class DataUserBusinessTextSerializerRead(DataUserBusinessTextSerializer):
    business = BusinessSerializer(read_only=True)

class FollowSerializer(serializers.ModelSerializer):
    class Meta:
        model = Follow
        fields = '__all__'

class FollowSerializerRead(FollowSerializer):
    follower = UserSerializer(read_only=True)
    followed = UserSerializer(read_only=True)

class ActivitySerializer(serializers.ModelSerializer):
    class Meta:
        model = Activity
        fields = '__all__'

class ActivitySerializerRead(ActivitySerializer):
    user = UserSerializer(read_only=True)
    field = FieldSerializer(read_only=True)

class ShareSerializer(serializers.ModelSerializer):
    class Meta:
        model = Share
        fields = '__all__'

class ShareSerializerRead(ShareSerializer):
    user = UserSerializer(read_only=True)
    business = BusinessSerializer(read_only=True)



