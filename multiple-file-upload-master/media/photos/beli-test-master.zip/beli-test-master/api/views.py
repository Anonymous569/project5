from backoffice.models import DataUserBusinessInteger, Field, Business, DataBusinessBoolean, User, DataUserBusinessBoolean, DataUserBoolean, Share, DataBusinessInteger, DataBusinessFloat, DataUserBusinessText, Follow, ParameterFloat, Activity
from api.serializers import *
from rest_framework import generics, permissions
import pandas as pd
from django_filters.rest_framework import DjangoFilterBackend
from rest_framework.response import Response
from rest_framework import mixins, status
from rest_framework.views import APIView
from calculators.recommendations import RecommendationCalculator
from django.db.models import Count

class ActivityListView(generics.ListCreateAPIView):
    queryset = Activity.objects.all()

    filter_backends = (DjangoFilterBackend,)
    filterset_fields = ('id','user','field')

    def get_serializer_class(self):
        if self.request.method in ['GET']:
            return ActivitySerializerRead
        return ActivitySerializer

class ShareListView(generics.ListCreateAPIView):
    queryset = Share.objects.all()

    filter_backends = (DjangoFilterBackend,)
    filterset_fields = ('id','user','business')

    def get_serializer_class(self):
        if self.request.method in ['GET']:
            return ShareSerializerRead
        return ShareSerializer

class DataBusinessBooleanListView(generics.ListCreateAPIView):
    queryset = DataBusinessBoolean.objects.filter(end_dt__isnull=True)

    filter_backends = (DjangoFilterBackend,)
    filterset_fields = ('id','field','business','value')

    def get_serializer_class(self):
        if self.request.method in ['GET']:
            return DataBusinessBooleanSerializerRead
        return DataBusinessBooleanSerializer

class DataBusinessIntegerListView(generics.ListCreateAPIView):
    queryset = DataBusinessInteger.objects.filter(end_dt__isnull=True)

    filter_backends = (DjangoFilterBackend,)
    filterset_fields = ('id','field','business','value')

    def get_serializer_class(self):
        if self.request.method in ['GET']:
            return DataBusinessIntegerSerializerRead
        return DataBusinessIntegerSerializer

class DataBusinessFloatListView(generics.ListCreateAPIView):
    queryset = DataBusinessFloat.objects.filter(end_dt__isnull=True)

    filter_backends = (DjangoFilterBackend,)
    filterset_fields = ('id','field','business','value')

    def get_serializer_class(self):
        if self.request.method in ['GET']:
            return DataBusinessFloatSerializerRead
        return DataBusinessFloatSerializer

class DataBusinessVarcharListView(generics.ListCreateAPIView):
    queryset = DataBusinessVarchar.objects.filter(end_dt__isnull=True)

    filter_backends = (DjangoFilterBackend,)
    filterset_fields = ('id','field','business','value')

    def get_serializer_class(self):
        if self.request.method in ['GET']:
            return DataBusinessVarcharSerializerRead
        return DataBusinessVarcharSerializer      

class BusinessListView(generics.ListCreateAPIView):
    queryset = Business.objects.all()

    filter_backends = (DjangoFilterBackend,)
    filterset_fields = ('id','name','place_id')

    def get_serializer_class(self):
        if self.request.method in ['GET']:
            return BusinessSerializer
        return BusinessSerializer     

    """
    def get_queryset(self):
        queryset = Business.objects.all()

        try:
            queryset = queryset.filter(place_id=self.kwargs['place_id'])
        except KeyError:
            pass

        return queryset
    """

class FieldListView(generics.ListCreateAPIView):
    serializer_class = FieldSerializer

    filter_backends = (DjangoFilterBackend,)
    filterset_fields = ('id','name','table')

    def get_queryset(self):
        return Field.objects.all()

class RankingRecoverView(generics.GenericAPIView):

    def get(self, request):
        pass

class DataUserBusinessIntegerCloseView(generics.GenericAPIView):
    
    def get(self, request):
        kwargs = {'end_dt__isnull':True}

        for key in ('user','business','field'):
            if pd.notnull(self.request.GET.get(key)):
                kwargs[key] = self.request.GET.get(key)

        existing = DataUserBusinessInteger.objects.filter(**kwargs)
        existing.update(end_dt=pd.to_datetime('now'))

        return Response()

class DataUserBusinessBooleanCloseView(generics.GenericAPIView):
    
    def get(self, request):
        kwargs = {'end_dt__isnull':True}

        for key in ('user','business','field'):
            if pd.notnull(self.request.GET.get(key)):
                kwargs[key] = self.request.GET.get(key)

        existing = DataUserBusinessBoolean.objects.filter(**kwargs)
        existing.update(end_dt=pd.to_datetime('now'))

        return Response()

class DataUserBusinessTextCloseView(generics.GenericAPIView):
    
    def get(self, request):
        existing = DataUserBusinessText.objects.filter(
            user=self.request.GET.get('user'), 
            business=self.request.GET.get('business'), 
            field=self.request.GET.get('field')
        )
        existing.update(end_dt=pd.to_datetime('now'))

        return Response()      

class DataUserBusinessIntegerListView(generics.ListCreateAPIView):
    #serializer_class = DataUserBusinessIntegerSerializer

    filter_backends = (DjangoFilterBackend,)
    filterset_fields = ('user','field','business','value')

    def get_serializer_class(self):
        # Define your HTTP method-to-serializer mapping freely.
        # This also works with CoreAPI and Swagger documentation,
        # which produces clean and readable API documentation,
        # so I have chosen to believe this is the way the
        # Django REST Framework author intended things to work:
        if self.request.method in ['GET']:
            # Since the ReadSerializer does nested lookups
            # in multiple tables, only use it when necessary
            return DataUserBusinessIntegerSerializerRead
        return DataUserBusinessIntegerSerializer

    def get_queryset(self):
        queryset = DataUserBusinessInteger.objects.all()
        queryset = queryset.filter(end_dt__isnull=True).order_by('value')

        return queryset

    def create(self, request, *args, **kwargs):

        serializer = self.get_serializer(data=request.data, many=True)
        serializer.is_valid(raise_exception=True)

        self.perform_create(serializer)

        return Response()

class DataUserBusinessBooleanListView(generics.ListCreateAPIView):

    def get_queryset(self):
        queryset = DataUserBusinessBoolean.objects.all()
        queryset = queryset.filter(end_dt__isnull=True)

        return queryset

    filter_backends = (DjangoFilterBackend,)
    filterset_fields = ('id','user','business','field','value')

    def get_serializer_class(self):
        if self.request.method in ['GET']:
            return DataUserBusinessBooleanSerializerRead
        return DataUserBusinessBooleanSerializer

    def create(self, request, *args, **kwargs):

        serializer = self.get_serializer(data=request.data, many=True)
        serializer.is_valid(raise_exception=True)

        self.perform_create(serializer)

        return Response()

class DataUserBusinessTextListView(generics.ListCreateAPIView):

    def get_queryset(self):
        queryset = DataUserBusinessText.objects.all()
        queryset = queryset.filter(end_dt__isnull=True)

        return queryset

    filter_backends = (DjangoFilterBackend,)
    filterset_fields = ('id','user','business','field','value')

    def get_serializer_class(self):
        if self.request.method in ['GET']:
            return DataUserBusinessTextSerializerRead
        return DataUserBusinessTextSerializer

    def create(self, request, *args, **kwargs):

        serializer = self.get_serializer(data=request.data, many=True)
        serializer.is_valid(raise_exception=True)

        self.perform_create(serializer)

        return Response()

class UserListView(generics.ListCreateAPIView):
    """
    create:
        add users
    get:
        Search or get users
        You can search using:
            :param email
            :param username
    """
    #permission_classes = [permissions.IsAuthenticated]
    queryset = User.objects.all()
    serializer_class = UserSerializer

    filter_backends = (DjangoFilterBackend,)
    filterset_fields = ('id','first_name','last_name','email','password')

class DataUserBooleanListView(generics.ListCreateAPIView):
    queryset = DataUserBoolean.objects.all()
    serializer_class = DataUserBooleanSerializer

    filter_backends = (DjangoFilterBackend,)
    filterset_fields = ('id','user','field','value')

class FollowListView(generics.ListCreateAPIView, mixins.UpdateModelMixin):

    queryset = Follow.objects.all()

    def get_queryset(self):
        queryset = Follow.objects.all()
        queryset = queryset.filter(unfollow_dt__isnull=True)
        queryset = queryset.filter(unaccept_dt__isnull=True)

        return queryset

    def get_serializer_class(self):
        if self.request.method in ['GET']:
            return FollowSerializerRead
        return FollowSerializer

    def put(self, request, *args, **kwargs):
        return self.partial_update(request, *args, **kwargs)

    filter_backends = (DjangoFilterBackend,)
    filterset_fields = ('follower','followed')

class CorrView(APIView):

    def get(self, request, *args, **kwargs):

        data = DataUserBusinessInteger.objects.all()

        # filter for RANK data
        rank_field_id = Field.objects.filter(name='RANK').values()[0]['id']
        data = data.filter(field=rank_field_id)

        # filter for specified users
        data = data.filter(user__in=[kwargs['user_1'], kwargs['user_2']])

        # filter for active
        data = data.filter(end_dt__isnull=True)

        # convert to pandas dataframe
        df = pd.DataFrame.from_records(data.values())

        # pivot data
        pivot = df.pivot(index='business_id', columns='user_id', values='value')
        
        # calculate Kendall Tau corr
        matrix = pivot.corr(method='kendall')
        corr = matrix.iat[0,1]

        if pd.isnull(corr):
            return Response(None)
        else:
            return Response(corr)

class RecommendationView(APIView):

    def _get_rank_data(self):
        data = DataUserBusinessInteger.objects.filter(end_dt__isnull=True)

        rank_field_id = Field.objects.filter(name='RANK').values()[0]['id']
        data = data.filter(field=rank_field_id)

        rank_data = pd.DataFrame.from_records(data.values())

        rank_data.loc[:,'user_id'] = rank_data.loc[:,'user_id'].astype(str)

        return rank_data

    def _get_like_data(self):
        data = DataUserBusinessInteger.objects.filter(end_dt__isnull=True)
        
        like_field_id = Field.objects.filter(name='LIKECODE').values()[0]['id']
        data = data.filter(field=like_field_id)

        like_data = pd.DataFrame.from_records(data.values())

        like_data.loc[:,'user_id'] = like_data.loc[:,'user_id'].astype(str)

        return like_data

    def get(self, request, *args, **kwargs):

        # get min_corr parameter
        field = Field.objects.filter(name='MIN_CORR').values()[0]['id']
        min_corr = ParameterFloat.objects.filter(field=field).filter(end_dt__isnull=True).values()[0]['value']

        # RANK data
        rank_data = self._get_rank_data()

        # LIKECODE data
        like_data = self._get_like_data()

        # initialize calculator
        calc = RecommendationCalculator(
            rank_data=rank_data, 
            like_data=like_data,
            user_id=kwargs['user'], 
            min_corr=min_corr
        )

        recs = calc.get_recommendations()
        recs.columns = ['business_id','expected_percentile']
        
        recs = recs.to_dict('records')

        return Response(recs)

class UserBusinessDataCountView(generics.ListAPIView):

    def get(self, request, *args, **kwargs):
        queryset = self.get_queryset(**kwargs)
        return Response(queryset)

    def get_queryset(self, **kwargs):

        queryset = DataUserBusinessInteger.objects.filter(field=kwargs['field']).filter(end_dt__isnull=True)
        queryset = queryset.values('user').annotate(count=Count('user')).order_by('-count')

        return queryset

        


