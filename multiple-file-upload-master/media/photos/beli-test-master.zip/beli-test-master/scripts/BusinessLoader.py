#from DBDataFrameWriter import DBDataFrameWriter
import requests
import json
import pandas as pd

CONFIG = {
'API_HOST':"https://api.yelp.com",
'SEARCH_PATH':"/v3/businesses/search",
'BUSINESS_PATH':"/v3/businesses/",  # trailing / because we append the business id to the path
'API_KEY':"I_3gwq_r7uC8zFunYKLN6cOHj5cmBjAyi16uiXRoHqv4fdm5nRtFcGyH7vrhYATZVbcUI4uZkzqjtRUqMrdPM0eQXZTV39ihCkLTeWlgnphBmvOdGvaZhAa8bbcoXXYx"
}

headers = {'Authorization': 'Bearer %s' % CONFIG['API_KEY']}

class YelpApiAdapter():

    def __init__(self):
        self.url = "{API_HOST}{SEARCH_PATH}".format(**CONFIG)

    def get_all(self, term='restaurants', location='Brooklyn, Manhattan'):
        req = requests.get(self.url, params={'term':term,'location':location,'offset':0,'sort_by':'rating','price':'2,3,4'}, headers=headers)
        parsed = json.loads(req.text)
        businesses = parsed["businesses"]

        df = pd.DataFrame(businesses)

        print(df.tail()[['name','rating','price']])
        print(df.columns)
        print(df.shape)

    def write_all(self):
        pass




if __name__ == '__main__':
    adapter = YelpApiAdapter()
    adapter.get_all()
    