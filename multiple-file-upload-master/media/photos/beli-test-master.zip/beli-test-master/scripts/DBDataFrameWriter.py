from sqlalchemy import create_engine
import pandas as pd
from django.conf import settings

CONFIG = {
'PORT':'5432',
'HOST':'b96ekofgwcucuebcliyv-postgresql.services.clever-cloud.com',
'NAME':'b96ekofgwcucuebcliyv',
'PASSWORD':'3iIapF77XQUE71j5Lgcd',
'USER':'ubeamyachabgfyrtlrbd'
}

class DBDataFrameWriter():
    def __init__(self, config=CONFIG):
        #self.conn = psycopg2.connect("host='{HOST}' port={PORT} dbname='{NAME}' user={USER} password={PASSWORD}".format(**config))
        self.conn = create_engine("postgresql+psycopg2://{USER}:{PASSWORD}@{HOST}/{NAME}".format(**config))
        self.cnxn = self.conn.connect()

    def exec_sql(self, sql):
        self.cnxn.execute(sql)

    def _get_df(self, sql):
        df = pd.read_sql(sql=sql, con=self.conn)

        return df

    def write_df(self, df, table):
        df.to_sql(name=table, con=self.conn, if_exists='append', index=False, schema='public')

    def get_ranking(self, user_id):

        sql = """
        SELECT *
        FROM backoffice_datauserbusinessinteger
        WHERE user_id = {user_id}
        """.format(user_id=user_id)

        return self._get_df


if __name__ == '__main__':
    try:
        config = settings.DATABASES['default']
    except KeyError:
        config = {
        'PORT':'5432',
        'HOST':'b96ekofgwcucuebcliyv-postgresql.services.clever-cloud.com',
        'NAME':'b96ekofgwcucuebcliyv',
        'PASSWORD':'3iIapF77XQUE71j5Lgcd',
        'USER':'ubeamyachabgfyrtlrbd'
        }
    db = DBDataFrameWriter(config=config)

    df = db.get_df(sql="SELECT * FROM backoffice_user")
    print(df)