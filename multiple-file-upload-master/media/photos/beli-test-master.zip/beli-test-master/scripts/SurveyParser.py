import pandas as pd
from DBDataFrameWriter import DBDataFrameWriter
import choix
from itertools import combinations
from copy import deepcopy

class SurveyParser():

    def __init__(self, db_writer, path, file_name):
        self.db_writer = db_writer
        self.path = path
        self.file_path = path + '\\' + file_name
        self.file_path_new = path + '\\' + 'data_new.csv'
        #print(self.file_path)
        self.restaurants = pd.read_csv(path+'\\restaurants.csv', encoding='latin-1')
        self.restaurants_new = pd.read_csv(path+'\\restaurants_new.csv', encoding='latin-1')
        self.excel = pd.ExcelFile(self.path + '\\db.xlsx')

    def _restaurant_dict(self):
        self.restaurant_dict = dict(zip(self.restaurants['ID'],self.restaurants['name']))
        self.restaurant_new_dict = dict(zip(self.restaurants_new['ID'],self.restaurants_new['name']))
        #print(self.restaurant_dict)

    def parse(self):
        self.raw = pd.read_csv(self.file_path, encoding='latin-1')
        self.raw_new = pd.read_csv(self.file_path_new, encoding='latin-1')

        self._restaurant_dict()
        self._clean()

    def write_tab(self, tab):
        raw = self.excel.parse(tab)
        print(raw.head())

        self.db_writer.write_df(df=raw, table=tab)

    def tab_update(self, tab, column):
        raw = self.excel.parse(tab)
        for _, row in raw.iterrows():
            print(row)
            print(row[column])

            value = row[column]
            id_value = row['id']

            sql = f"""
            UPDATE {tab}
            SET {column} = '{value}'
            WHERE id = {id_value}
            """

            try:
                self.db_writer.exec_sql(sql)
            except Exception as e:
                print(e)
    
    def _clean(self, write=False):

        # old survey
        clean = deepcopy(self.raw)

        clean = clean.set_index('Q11').loc[:,self.restaurant_dict.keys()]
        clean.rename(columns=self.restaurant_dict, inplace=1)
        clean = clean.stack().reset_index()

        clean.columns = ['email','name','value']

        clean = clean.loc[clean['email'] != 'frost1722@gmail.com']

        # new survey
        clean_new = deepcopy(self.raw_new)

        clean_new = clean_new.set_index('Q11').loc[:,self.restaurant_new_dict.keys()]
        clean_new.rename(columns=self.restaurant_new_dict, inplace=1)
        clean_new = clean_new.stack().reset_index()

        clean_new.columns = ['email','name','value']

        # combine
        all_clean = pd.concat([clean, clean_new], axis=1)

        all_clean.loc[:,'value'] = clean.loc[:,'value'].astype(int)

        self.clean = all_clean

        if write:
            clean = clean.loc[clean['email'] == 'epfrost@mba2020.hbs.edu']
            clean.loc[:,'field_id'] = 1
            clean.loc[:,'user_id'] = 'b9c94de8-384a-4d44-98ae-cc6cdb12bed9'
            clean.loc[:,'start_dt'] = pd.to_datetime('now')

            businesses = self.db_writer._get_df(sql="SELECT * FROM backoffice_business")
            clean = clean.merge(businesses, on='name', how='left').rename(columns={'id':'business_id'})

            clean = clean.loc[:,['user_id','business_id','field_id','start_dt','value']]
            print(clean)
            
            #self.db_writer.write_df(df=clean, table='backoffice_datauserbusinessinteger')

        return clean

    def calc_recs(self, email, min_overlap=5):
        corr = self.clean.corr

    def get_recs(self, email):
        pivoted = self.clean.pivot_table(index='name', columns='email', values='value')
        print(pivoted.head())

        all_corr = pd.DataFrame(index=pivoted.columns, columns=pivoted.columns)
        all_count = pd.DataFrame(index=pivoted.columns, columns=pivoted.columns)
        
        for comb in combinations(pivoted.columns, 2):
            cols = pivoted.loc[:,comb].dropna()
            corr = pd.concat([cols[[c]].sort_values(by=c).any(axis=1).cumsum() for c in comb], axis=1, sort=True).corr()

            all_corr.loc[comb[0],comb[1]] = corr.iat[0,1]
            all_corr.loc[comb[1],comb[0]] = corr.iat[0,1]

            all_count.loc[comb[0],comb[1]] = len(cols)
            all_count.loc[comb[1],comb[0]] = len(cols)

            print(corr)

        return all_corr, all_count

    def write_restaurants(self):
        df = self.restaurants.loc[:,['name']]
        df.loc[:,'created_dt'] = pd.to_datetime('now')

        self.db_writer.write_df(df=df, table='backoffice_business')

if __name__ == '__main__':
    path = '..\..\..\survey'
    file_name = 'data.csv'

    db_writer = DBDataFrameWriter()
    parser = SurveyParser(path=path, file_name=file_name, db_writer=db_writer)

    #parser.parse()

    #df = parser.db_writer._get_df("SELECT * FROM backoffice_DataUserBusinessInteger")
    #df.to_clipboard()
    #for table in ['backoffice_DataUserBusinessInteger','backoffice_DataUserBusinessBoolean','backoffice_DataUserBusinessText','backoffice_DataUserBoolean']:
        #parser.db_writer.exec_sql("DELETE FROM %s WHERE user_id = 'd0de49d1-f50f-4d56-a16c-ce3c88f13378'" % table)
    
    #for table in ['backoffice_DataBusinessInteger','backoffice_DataBusinessFloat','backoffice_DataBusinessVarchar']:
        #parser.db_writer.exec_sql("DELETE FROM %s" % table)
    sql = """
    DELETE FROM backoffice_datauserbusinessinteger
    WHERE user_id = 'd0de49d1-f50f-4d56-a16c-ce3c88f13378'
    AND id >= 49422
    """

    sql = """
    SELECT *
    FROM backoffice_datauserbusinessinteger
    WHERE user_id = 'd0de49d1-f50f-4d56-a16c-ce3c88f13378'
    """

    #df = parser.db_writer._get_df(sql)
    #df.to_clipboard()

    sql = """
    DELETE FROM backoffice_datauserbusinessinteger
    WHERE user_id = 'd0de49d1-f50f-4d56-a16c-ce3c88f13378'
    AND id >= 97696
    AND field_id = 1
    """

    sql = """
    UPDATE backoffice_datauserbusinessinteger
    SET end_dt = NULL
    WHERE user_id = 'd0de49d1-f50f-4d56-a16c-ce3c88f13378'
    AND id >= 97577
    AND field_id = 1
    """

    sql = """
    INSERT INTO backoffice_City (name)

    SELECT DISTINCT city
    FROM backoffice_Business
    """

    parser.db_writer.exec_sql(sql)

    sql = """
    INSERT INTO backoffice_Follow (followed_id, follower_id, request_dt, accept_dt)
    SELECT
    share.author_id AS followed_id,
    u.id AS follower_id,
    share.created_dt AS request_dt,
    share.created_dt AS accept_dt

    FROM backoffice_Share share
    LEFT JOIN backoffice_User u
    ON share.sharee_email = u.email

    WHERE u.id IS NOT NULL
    """

    '''
    try:
        parser.db_writer.exec_sql(sql)
    except Exception as e:
        print(e)

    sql = "SELECT * FROM backoffice_Follow"

    df = parser.db_writer._get_df(sql)
    df.to_clipboard()
    '''

    sql = """
    INSERT INTO backoffice_DataBusinessBoolean (business_id, field_id, value, start_dt)

    SELECT business_id, 16, true, CURRENT_TIMESTAMP
    FROM backoffice_DataUserBusinessBoolean
    WHERE field_id = 9
    AND user_id = 'c709df41-3417-479b-9a6c-d66ac43db551'
    """

    '''
    sql = """
    UPDATE backoffice_User
    SET is_staff = true, is_superuser = true
    WHERE id = 'd0de49d1-f50f-4d56-a16c-ce3c88f13378'
    """
    '''

    '''
    sql = """
    '''





    sql = """
    UPDATE backoffice_DataBusinessBoolean
    SET field_id = 1
    WHERE field_id = 16
    """

    sql = """
    DELETE FROM backoffice_Field
    WHERE id = 16
    """

    sql = """
    INSERT INTO backoffice_Field ("name", "description", "table", created_dt)
    VALUES (
        'INITIALSELECTION_CHICAGO',
        'Business is included in initial selection and ranking on startup, for Chicago',
        'DataBusinessBoolean',
        CURRENT_TIMESTAMP
    )
    """



    sql = """
    DELETE FROM backoffice_Field
    WHERE id > 18
    """

    sql = """
    UPDATE backoffice_DataBusinessBoolean
    SET field_id = 18
    WHERE field_id = 1
    """

    sql = """
    INSERT INTO backoffice_Field ("name", "description", "table", created_dt)
    VALUES (
        'INITIALSELECTION_CHICAGO',
        'Business is included in initial selection and ranking on startup, for Chicago',
        'DataBusinessBoolean',
        CURRENT_TIMESTAMP
    )
    """

    sql = """
    UPDATE backoffice_DataBusinessBoolean
    SET field_id = 17
    WHERE field_id = 18
    """

    sql = """
    DELETE FROM backoffice_Field
    WHERE id = 18
    """

    sql = """
    INSERT INTO backoffice_Field ("name", "description", "table", created_dt)
    VALUES (
        'HASDONESURVEY_CHICAGO',
        'Has completed the initial select and rank survey',
        'DataUserBoolean',
        CURRENT_TIMESTAMP
    )
    """

    #parser.db_writer.exec_sql(sql)