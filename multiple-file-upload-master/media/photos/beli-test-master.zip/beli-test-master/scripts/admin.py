from DBDataFrameWriter import DBDataFrameWriter
import pandas as pd

class Admin(object):

    db = DBDataFrameWriter()

    def _get_field_id(self, field_name):

        sql = f"""
        SELECT id
        FROM backoffice_Field
        WHERE name = '{field_name}'
        """

        df = self.db._get_df(sql)
        value = df.iat[0,0]

        return value

    def add_field(self, name, description, table, created_dt=None):

        if pd.isnull(created_dt):
            created_dt = pd.datetime.now()

        sql = f"""
        INSERT INTO backoffice_Field (name, description, "table", created_dt)
        VALUES ('{name}', '{description}', '{table}', '{created_dt}')
        """

        self.db.exec_sql(sql)

    def add_parameter(self, value, field_id=None, field_name=None, start_dt=None):

        if pd.isnull(start_dt):
            start_dt = pd.datetime.now()

        if pd.isnull(field_id):
            field_id = self._get_field_id(field_name)

        sql = f"""
        INSERT INTO backoffice_ParameterFloat (field_id, value, start_dt)
        VALUES ('{field_id}', '{value}', '{start_dt}')
        """

        self.db.exec_sql(sql)

    def delete_user(self, user_id):
        sql = f"""
        DELETE FROM backoffice_DataUserBusinessInteger
        WHERE user_id = '{user_id}'
        """

        self.db.exec_sql(sql)

        sql = f"""
        DELETE FROM backoffice_Follow
        WHERE follower_id = '{user_id}'
        OR followed_id = '{user_id}'
        """

        self.db.exec_sql(sql)       

        sql = f"""
        DELETE FROM backoffice_DataUserBusinessBoolean
        WHERE user_id = '{user_id}'
        """

        self.db.exec_sql(sql)

        sql = f"""
        DELETE FROM backoffice_DataUserBusinessText
        WHERE user_id = '{user_id}'
        """

        self.db.exec_sql(sql)

        sql = f"""
        DELETE FROM backoffice_DataUserBoolean
        WHERE user_id = '{user_id}'
        """

        self.db.exec_sql(sql)

        sql = f"""
        DELETE FROM backoffice_Activity
        WHERE user_id = '{user_id}'
        """

        self.db.exec_sql(sql)

        sql = f"""
        DELETE FROM backoffice_User
        WHERE id = '{user_id}'
        """

        self.db.exec_sql(sql)


if __name__ == "__main__":
    admin = Admin()

    admin.delete_user(user_id='e1151bff-a727-4cea-9103-e1d73d5feb12')
    
    """
    admin.add_field(
        'MIN_CORR', 
        'minimum correlation required to qualify as a taste match', 
        'backoffice_ParameterFloat'
    )
    """